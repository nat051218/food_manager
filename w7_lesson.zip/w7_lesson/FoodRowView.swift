//
//  FoodRowView.swift
//  w7_lesson
//
//  Created by natalee chen on 29/10/2025.
//

import SwiftUI

struct FoodRowView: View {
    let food: Food
    
    var body: some View {
        HStack(spacing: 16) {
            Image(food.foodImage)
                .resizable()
                .scaledToFill()
                .frame(width: 50, height: 50)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.black.opacity(0.06))
                )
            
            VStack(alignment: .leading, spacing: 6) {
                Text(food.name)
                    .lineLimit(1)
                    .font(.headline)
                
                Text(food.storingPlace)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(Color("titleText"))
                    .lineLimit(2)
                    .minimumScaleFactor(0.9)
                
                HStack(spacing: 8) {
                    Text(food.type.rawValue)
                        .font(.caption.weight(.bold))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 4)
                        .background(Color.blue.opacity(0.15))
                        .cornerRadius(6)
                    
                    ExpirationChip(date: food.expirationDate)
                }
            }
            
            Spacer(minLength: 0)
        }
        .padding(.vertical, 8)
    }
}
