//
//  IntroStepView.swift
//  w7_lesson
//
//  Created by natalee chen on 28/10/2025.
//
import SwiftUI

struct IntroStepView: View {
    let recipe: RecipeItem

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Header
                VStack(alignment: .leading, spacing: 6) {
                    Text("Introduction")
                        .font(.headline)
                        .foregroundColor(.secondary)
                    Text("How to make \(recipe.title)")
                        .font(.title2.bold())
                        .foregroundColor(.primary)
                }
                .frame(maxWidth: 700)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal)

                // Hero image
                Image(recipe.imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 700)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                    .shadow(color: Color.black.opacity(0.12), radius: 6, x: 0, y: 3)
                    .overlay(
                        RoundedRectangle(cornerRadius: 18)
                            .strokeBorder(Color.black.opacity(0.05))
                    )
                    .padding(.horizontal)

                // Ingredients card
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 8) {
                        Image(systemName: "list.bullet")
                            .foregroundColor(.orange)
                        Text("Ingredients")
                            .font(.headline)
                            .foregroundColor(.orange)
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(recipe.ingredients, id: \.self) { item in
                            HStack(alignment: .top, spacing: 10) {
                                Circle()
                                    .fill(Color.orange)
                                    .frame(width: 6, height: 6)
                                    .padding(.top, 7)
                                Text(item)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }
                    }
                }
                .padding(16)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .shadow(color: Color.black.opacity(0.06), radius: 4, x: 0, y: 2)
                .frame(maxWidth: 700)
                .padding(.horizontal)
            }
            .padding(.vertical, 16)
        }
        .background(
            LinearGradient(colors: [Color("beige").opacity(0.95), Color("beige")],
                           startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
        )
    }
}
