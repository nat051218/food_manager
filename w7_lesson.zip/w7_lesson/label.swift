//
//  FoodLabel.swift
//  w7_lesson
//
//  Created by natalee chen on 17/10/2025.
//

import SwiftUI

struct FoodLabel: View {
    let food: Food
    
    var body: some View {
        HStack (spacing: 16){
            Image(food.foodImage)
                .resizable()
                .scaledToFit()
                .frame(width: 80, height: 80)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 4))
                .shadow(color: Color.black.opacity(0.15), radius: 6, x: 0, y: 4)
            
            VStack(alignment: .leading, spacing: 6) {
                Text(food.name)
                    .font(.title2.bold())
                    .foregroundColor(.primary)
                    .lineLimit(2)
                
                Text(food.expirationDate, style: .date)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            Spacer()
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color(.systemBackground).opacity(0.95))
                .shadow(color: Color.black.opacity(0.05), radius: 6, x: 0, y: 3)
        )
        .padding(.horizontal)
    }
}

#Preview {
    FoodLabel(
        food: Food(
            name: "Watermelon",
            type: .fresh,
            expirationDate: Calendar.current.date(from: DateComponents(year: 2025, month: 10, day: 19)) ?? Date(),
            storingPlace: "Fridge - Crisper Drawer",
            foodImage: "watermelon"
        )
    )
}
