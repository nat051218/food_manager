//
//  ContentView.swift
//  w7_lesson
//
//  Created by natalee chen on 17/10/2025.
//

import SwiftUI

struct ContentView: View {
    private let foods: [Food] = [
        Food(name: "Croissant", type: .pastry,
             expirationDate: Calendar.current.date(from: DateComponents(year: 2025, month: 11, day: 20)) ?? Date(),
             storingPlace: "Pantry", foodImage: "croissant"),
        Food(name: "Watermelon", type: .fresh,
             expirationDate: Calendar.current.date(from: DateComponents(year: 2025, month: 11, day: 18)) ?? Date(),
             storingPlace: "Fridge - Crisper Drawer", foodImage: "watermelon"),
        Food(name: "Animal Cracker", type: .dryGoods,
             expirationDate: Calendar.current.date(from: DateComponents(year: 2025, month: 12, day: 07)) ?? Date(),
             storingPlace: "Snack Box", foodImage: "animalCracker"),
        Food(name: "Mango", type: .fresh,
             expirationDate: Calendar.current.date(from: DateComponents(year: 2025, month: 11, day: 13)) ?? Date(),
             storingPlace: "Fridge - Crisp Drawer", foodImage: "mango"),
        Food(name: "Lemon Tart", type: .pastry,
             expirationDate: Calendar.current.date(from: DateComponents(year: 2025, month: 10, day: 27)) ?? Date(),
             storingPlace: "Fridge - Second Shelf", foodImage: "lemonTart"),
        Food(name: "Bento", type: .cooked,
             expirationDate: Calendar.current.date(from: DateComponents(year: 2025, month: 11, day: 14)) ?? Date(),
             storingPlace: "Fridge - Bottom Shelf", foodImage: "bento")
    ]
    
    var body: some View {
        ZStack {
            Color("beige")
                .ignoresSafeArea()
            
            List {
                ForEach(FoodType.allCases, id: \.self) { type in
                    let items = foods.filter { $0.type == type }
                    if !items.isEmpty {
                        Section {
                            ForEach(items) { item in
                                NavigationLink(destination: InfoCard(food: item)) {
                                    FoodRowView(food: item)
                                }
                                .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                                .listRowSeparator(.visible)
                                .listRowSeparatorTint(Color.black.opacity(0.06))
                            }
                        } header: {
                            Text(type.rawValue)
                                .font(.headline.weight(.semibold))
                                .textCase(nil)
                                .padding(.leading, 8)
                                .padding(.top, 4)
                                .padding(.bottom, 2)
                        }
                    }
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden) // hide List’s default bg
            .listSectionSpacing(.custom(8))
        }
        .navigationTitle("Nat’s Food Storage")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarBackground(Color("beige"), for: .navigationBar)
        .toolbarColorScheme(.light, for: .navigationBar)
    }
}



